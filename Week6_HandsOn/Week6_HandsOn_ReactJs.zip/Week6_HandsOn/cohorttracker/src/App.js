import React from 'react';
import CohortDetails from './CohortDetails';

function App() {
  const cohorts = [
    {
      title: 'React Basics',
      startDate: '2025-06-01',
      endDate: '2025-07-01',
      status: 'ongoing'
    },
    {
      title: 'Advanced React',
      startDate: '2025-04-15',
      endDate: '2025-05-15',
      status: 'completed'
    }
  ];

  return (
    <div>
      <h1>Cohort Dashboard</h1>
      {cohorts.map((cohort, index) => (
        <CohortDetails key={index} cohort={cohort} />
      ))}
    </div>
  );
}

export default App;
