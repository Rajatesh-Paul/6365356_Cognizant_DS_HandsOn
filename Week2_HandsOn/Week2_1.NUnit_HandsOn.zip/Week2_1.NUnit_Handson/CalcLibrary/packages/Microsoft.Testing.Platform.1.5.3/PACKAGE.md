# Microsoft.Testing

Microsoft Testing is a set of platform, framework and protocol intended to make it possible to run any test on any target or device.

Documentation can be found at <https://aka.ms/testingplatform>.

## About

This package provides the test platform.
