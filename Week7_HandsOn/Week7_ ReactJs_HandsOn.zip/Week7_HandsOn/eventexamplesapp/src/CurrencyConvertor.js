import React, { Component } from "react";

class CurrencyConvertor extends Component {
  constructor(props) {
    super(props);
    this.state = {
      rupees: "",
      euros: ""
    };
  }

  // Handle change in rupees input
  handleRupeesChange = (event) => {
    this.setState({ rupees: event.target.value });
  };

  // Handle form submission for conversion
  handleSubmit = (event) => {
    event.preventDefault();
    const euroValue = (parseFloat(this.state.rupees) / 90).toFixed(2); // Approx rate
    this.setState({ euros: euroValue });
  };

  render() {
    return (
      <div>
        <h2>Currency Convertor (INR → EUR)</h2>
        <form onSubmit={this.handleSubmit}>
          <input
            type="number"
            placeholder="Enter amount in INR"
            value={this.state.rupees}
            onChange={this.handleRupeesChange}
          />
          <button type="submit">Convert</button>
        </form>
        {this.state.euros && (
          <p>
            ₹{this.state.rupees} = €{this.state.euros}
          </p>
        )}
      </div>
    );
  }
}

export default CurrencyConvertor;
