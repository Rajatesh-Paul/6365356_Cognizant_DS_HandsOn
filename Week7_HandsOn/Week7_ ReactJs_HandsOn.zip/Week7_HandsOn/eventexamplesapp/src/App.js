import React, { Component } from "react";
import CurrencyConvertor from "./CurrencyConvertor";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      counter: 0
    };
  }

  // Method to increment counter
  increment = () => {
    this.setState(prevState => ({ counter: prevState.counter + 1 }));
  };

  // Method to decrement counter
  decrement = () => {
    this.setState(prevState => ({ counter: prevState.counter - 1 }));
  };

  // Say Hello
  sayHello = () => {
    alert("Hello! This is a static message.");
  };

  // Multiple methods for increment button
  handleIncrementClick = () => {
    this.increment();
    this.sayHello();
  };

  // Method with argument
  sayMessage = (msg) => {
    alert(msg);
  };

  // Synthetic event example
  handleSyntheticEvent = (event) => {
    alert("I was clicked");
    console.log("Synthetic Event Object:", event);
  };

  render() {
    return (
      <div style={{ padding: "20px" }}>
        <h1>React Event Examples App</h1>

        <h2>Counter: {this.state.counter}</h2>
        <button onClick={this.handleIncrementClick}>Increment</button>
        <button onClick={this.decrement}>Decrement</button>

        <hr />

        <button onClick={() => this.sayMessage("Welcome")}>Say Welcome</button>

        <hr />

        <button onClick={this.handleSyntheticEvent}>Synthetic Event (OnPress)</button>

        <hr />

        <CurrencyConvertor />
      </div>
    );
  }
}

export default App;
