import React from "react";

// Inline CSS styles
const headingStyle = {
  textAlign: "center",
  color: "#333",
  margin: "20px 0"
};

function App() {
  // Office object
  const office = {
    name: "Prime Office Space",
    rent: 55000,
    address: "123 Business Street, Mumbai",
    image: "https://via.placeholder.com/300x200?text=Office+Space"
  };

  // List of office spaces
  const officeList = [
    { name: "Tech Hub", rent: 75000, address: "456 IT Park, Bangalore" },
    { name: "Startup Zone", rent: 50000, address: "789 Startup St, Pune" },
    { name: "Corporate Tower", rent: 90000, address: "101 Tower Road, Delhi" },
    { name: "Shared Workspace", rent: 45000, address: "202 Cowork St, Hyderabad" }
  ];

  // Function to set rent color based on amount
  const rentStyle = (rent) => ({
    color: rent < 60000 ? "red" : "green",
    fontWeight: "bold"
  });

  return (
    <div>
      {/* Heading */}
      <h1 style={headingStyle}>Office Space Rental App</h1>

      {/* Single Office Display */}
      <div style={{ textAlign: "center", marginBottom: "30px" }}>
        <img src={office.image} alt="Office Space" style={{ borderRadius: "8px" }} />
        <h2>{office.name}</h2>
        <p style={rentStyle(office.rent)}>Rent: ₹{office.rent}</p>
        <p>{office.address}</p>
      </div>

      {/* List of Offices */}
      <div style={{ maxWidth: "600px", margin: "0 auto" }}>
        <h2>Available Office Spaces</h2>
        {officeList.map((o, index) => (
          <div
            key={index}
            style={{
              backgroundColor: "#f9f9f9",
              padding: "10px",
              margin: "10px 0",
              borderRadius: "5px"
            }}
          >
            <h3>{o.name}</h3>
            <p style={rentStyle(o.rent)}>Rent: ₹{o.rent}</p>
            <p>{o.address}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
