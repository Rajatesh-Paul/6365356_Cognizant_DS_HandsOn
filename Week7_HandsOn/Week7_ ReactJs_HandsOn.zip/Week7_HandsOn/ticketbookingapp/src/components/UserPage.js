import React from 'react';
import FlightList from './FlightList';

function UserPage() {
  return (
    <div>
      <h2>Welcome, User!</h2>
      <p>You can now book tickets.</p>
      <FlightList canBook />
    </div>
  );
}

export default UserPage;
