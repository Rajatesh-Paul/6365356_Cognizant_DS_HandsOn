import React from 'react';

const flights = [
  { id: 1, from: 'New York', to: 'London', price: 600 },
  { id: 2, from: 'Delhi', to: 'Dubai', price: 300 },
  { id: 3, from: 'Paris', to: 'Tokyo', price: 800 },
];

function FlightList({ canBook = false }) {
  return (
    <div>
      <h3>Available Flights</h3>
      <ul>
        {flights.map(flight => (
          <li key={flight.id}>
            {flight.from} → {flight.to} (${flight.price})
            {canBook && <button style={{ marginLeft: 10 }}>Book</button>}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default FlightList;
