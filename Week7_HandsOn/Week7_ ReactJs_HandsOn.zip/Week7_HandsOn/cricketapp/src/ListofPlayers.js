import React from "react";

function ListofPlayers() {
  const players = [
    { name: "Virat Kohli", score: 85 },
    { name: "Rohit Sharma", score: 95 },
    { name: "KL Rahul", score: 60 },
    { name: "Shreyas Iyer", score: 72 },
    { name: "Rishabh Pant", score: 50 },
    { name: "Hardik Pandya", score: 88 },
    { name: "Ravindra Jadeja", score: 65 },
    { name: "Jasprit Bumrah", score: 40 },
    { name: "Bhuvneshwar Kumar", score: 78 },
    { name: "Yuzvendra Chahal", score: 45 },
    { name: "Mohammed Shami", score: 69 }
  ];

  // Filter players below 70 using arrow function
  const lowScorePlayers = players.filter(player => player.score < 70);

  return (
    <div>
      <h2>All Players</h2>
      {players.map((p, index) => (
        <p key={index}>{p.name} - {p.score}</p>
      ))}

      <h2>Players with Score Below 70</h2>
      {lowScorePlayers.map((p, index) => (
        <p key={index}>{p.name} - {p.score}</p>
      ))}
    </div>
  );
}

export default ListofPlayers;
