import React from "react";

function IndianPlayers() {
  const oddPlayers = ["Virat", "Rahul", "Iyer"];
  const evenPlayers = ["Rohit", "Pant", "Shikhar"];

  // Destructuring
  const [odd1, odd2, odd3] = oddPlayers;
  const [even1, even2, even3] = evenPlayers;

  // Merge arrays
  const T20players = ["Hardik", "Bumrah"];
  const RanjiTrophyPlayers = ["Pujara", "Jadeja"];
  const allPlayers = [...T20players, ...RanjiTrophyPlayers];

  return (
    <div>
      <h2>Odd Team Players</h2>
      <p>{odd1}, {odd2}, {odd3}</p>

      <h2>Even Team Players</h2>
      <p>{even1}, {even2}, {even3}</p>

      <h2>Merged List of T20 & Ranji Trophy Players</h2>
      {allPlayers.map((p, i) => <p key={i}>{p}</p>)}
    </div>
  );
}

export default IndianPlayers;
