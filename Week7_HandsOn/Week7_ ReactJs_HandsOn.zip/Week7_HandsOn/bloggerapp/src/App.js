import React, { useState } from 'react';
import Selector from './components/Selector';
import BookDetails from './components/BookDetails';
import BlogDetails from './components/BlogDetails';
import CourseDetails from './components/CourseDetails';

function App() {
  const [selected, setSelected] = useState('book');

  // Conditional rendering using element variable
  let content;
  if (selected === 'book') {
    content = <BookDetails />;
  } else if (selected === 'blog') {
    content = <BlogDetails />;
  } else if (selected === 'course') {
    content = <CourseDetails />;
  }

  return (
    <div>
      <h1>Blogger App</h1>
      <Selector onChange={setSelected} />
      
      {/* Conditional rendering using ternary operator */}
      <h2>Currently Viewing: {selected === 'book' ? 'Books' : selected === 'blog' ? 'Blogs' : 'Courses'}</h2>
      
      {/* Rendered via element variable (if-else) */}
      {content}
    </div>
  );
}

export default App;
