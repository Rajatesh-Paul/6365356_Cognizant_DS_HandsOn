import React from 'react';

function Selector({ onChange }) {
  return (
    <div>
      <button onClick={() => onChange('book')}>Book Details</button>
      <button onClick={() => onChange('blog')}>Blog Details</button>
      <button onClick={() => onChange('course')}>Course Details</button>
    </div>
  );
}

export default Selector;
