import React from 'react';

const blogs = [
  { id: 1, title: 'Understanding JSX', author: 'Jane' },
  { id: 2, title: 'Hooks in Depth', author: 'John' },
];

function BlogDetails() {
  return (
    <div>
      <h3>Blog Articles</h3>
      <ul>
        {blogs.length > 0 && blogs.map(blog => (
          <li key={blog.id}>
            <strong>{blog.title}</strong> by {blog.author}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default BlogDetails;
