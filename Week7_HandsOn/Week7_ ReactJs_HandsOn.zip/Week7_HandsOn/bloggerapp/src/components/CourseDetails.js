import React from 'react';

const courses = [];

function CourseDetails() {
  return (
    <div>
      <h3>Available Courses</h3>
      {/* Conditional rendering using logical AND */}
      {courses.length === 0 && <p>No courses available.</p>}
    </div>
  );
}

export default CourseDetails;
