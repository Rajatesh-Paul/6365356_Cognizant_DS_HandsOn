import React from 'react';

const books = [
  { id: 1, title: 'React Explained', author: 'Zac Gordon' },
  { id: 2, title: 'Learning React', author: 'Alex Banks' },
];

function BookDetails() {
  return (
    <div>
      <h3>Book List</h3>
      <ul>
        {books.map(book => (
          <li key={book.id}>
            {book.title} by {book.author}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default BookDetails;
